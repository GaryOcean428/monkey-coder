"""
Application package for Monkey Coder.

Contains the FastAPI application main module and related components.
"""

__all__ = ['main']